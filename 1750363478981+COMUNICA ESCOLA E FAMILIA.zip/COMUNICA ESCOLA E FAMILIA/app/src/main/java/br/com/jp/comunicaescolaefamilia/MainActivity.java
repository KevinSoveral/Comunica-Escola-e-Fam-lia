package br.com.jp.comunicaescolaefamilia;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    private EditText editTextAluno;
    private EditText editTextTurma;
    private EditText editTextAssunto;
    private EditText editTextDescricao;
    private Button buttonFinalizar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicializa os elementos da UI
        editTextAluno = findViewById(R.id.edit_text_aluno);
        editTextTurma = findViewById(R.id.edit_text_turma);
        editTextAssunto = findViewById(R.id.edit_text_assunto);
        editTextDescricao = findViewById(R.id.edit_text_descricao);
        buttonFinalizar = findViewById(R.id.button_finalizar);

        // Define o listener de clique para o botão "Finalizar Atendimento"
        buttonFinalizar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Obtém os textos digitados nos campos
                String aluno = editTextAluno.getText().toString();
                String turma = editTextTurma.getText().toString();
                String assunto = editTextAssunto.getText().toString();
                String descricao = editTextDescricao.getText().toString();

                // Cria uma Intent para iniciar a SummaryActivity
                Intent intent = new Intent(MainActivity.this, SummaryActivity.class);

                // Adiciona os dados como extras na Intent
                intent.putExtra("aluno", aluno);
                intent.putExtra("turma", turma);
                intent.putExtra("assunto", assunto);
                intent.putExtra("descricao", descricao);

                // Inicia a SummaryActivity
                startActivity(intent);
            }
        });
    }
}
