package br.com.jp.comunicaescolaefamilia;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast; // Importe Toast para mensagens curtas

public class SummaryActivity extends AppCompatActivity {

    private TextView textSummaryAluno;
    private TextView textSummaryTurma;
    private TextView textSummaryAssunto;
    private TextView textSummaryDescricao;
    private Button buttonCompartilhar;

    private String summaryText; // Variável para armazenar o texto do resumo

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_summary);

        // Inicializa os elementos da UI
        textSummaryAluno = findViewById(R.id.text_summary_aluno);
        textSummaryTurma = findViewById(R.id.text_summary_turma);
        textSummaryAssunto = findViewById(R.id.text_summary_assunto);
        textSummaryDescricao = findViewById(R.id.text_summary_descricao);
        buttonCompartilhar = findViewById(R.id.button_compartilhar);

        // Obtém os dados passados da MainActivity
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            String aluno = extras.getString("aluno");
            String turma = extras.getString("turma");
            String assunto = extras.getString("assunto");
            String descricao = extras.getString("descricao");

            // Define o texto nos TextViews
            textSummaryAluno.setText("ALUNO: " + aluno);
            textSummaryTurma.setText("TURMA: " + turma);
            textSummaryAssunto.setText("ASSUNTO: " + assunto);
            textSummaryDescricao.setText("DESCRIÇÃO: " + descricao);

            // Monta o texto completo do resumo para compartilhamento
            summaryText = "Comunica Escola e Família\n\n" +
                    "ALUNO: " + aluno + "\n" +
                    "TURMA: " + turma + "\n" +
                    "ASSUNTO: " + assunto + "\n" +
                    "DESCRIÇÃO: " + descricao + "\n\n" +
                    "Mensagem gerada pelo aplicativo Comunica Escola e Família.";
        }

        // Define o listener de clique para o botão "Compartilhar"
        buttonCompartilhar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (summaryText != null && !summaryText.isEmpty()) {
                    shareSummary();
                } else {
                    Toast.makeText(SummaryActivity.this, "Nenhum resumo para compartilhar.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void shareSummary() {
        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType("text/plain");
        shareIntent.putExtra(Intent.EXTRA_TEXT, summaryText);
        shareIntent.setPackage("com.whatsapp"); // Tenta abrir diretamente o WhatsApp

        try {
            startActivity(shareIntent);
        } catch (android.content.ActivityNotFoundException ex) {
            // Se o WhatsApp não estiver instalado, oferece outras opções de compartilhamento
            shareIntent.setPackage(null); // Remove o pacote específico
            startActivity(Intent.createChooser(shareIntent, "Compartilhar resumo via..."));
        }
    }
}
